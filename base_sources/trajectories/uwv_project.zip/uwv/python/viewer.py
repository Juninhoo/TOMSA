"""Underwater robot trajectory viewer (Plotly, 3D).

Input columns pose.pose.position.{x,y,z} are geodetic: latitude [deg],
longitude [deg], ellipsoidal height h [m]. They are converted to a common
local tangent frame (East, North, Depth) in metres:

    geodetic -> ECEF (WGS84) -> NED about a common origin at height h_ref (water surface);
the NED 'Down' component is then the depth below the surface

Usage:  python viewer.py [--data ../data] [--out trajectories.html] [--h-ref 56.5]
"""
import argparse
import glob
import os

import numpy as np
import pandas as pd
import plotly.graph_objects as go

# WGS84 ellipsoid
A = 6378137.0                 # semi-major axis [m]
F = 1.0 / 298.257223563       # flattening
E2 = F * (2.0 - F)            # first eccentricity squared


def geodetic_to_ecef(lat_deg, lon_deg, h):
    lat, lon = np.radians(lat_deg), np.radians(lon_deg)
    n = A / np.sqrt(1.0 - E2 * np.sin(lat) ** 2)          # prime vertical radius
    x = (n + h) * np.cos(lat) * np.cos(lon)
    y = (n + h) * np.cos(lat) * np.sin(lon)
    z = (n * (1.0 - E2) + h) * np.sin(lat)
    return np.column_stack((x, y, z))


def ecef_to_ned(p_ecef, lat0_deg, lon0_deg, h0):
    lat0, lon0 = np.radians(lat0_deg), np.radians(lon0_deg)
    sl, cl, so, co = np.sin(lat0), np.cos(lat0), np.sin(lon0), np.cos(lon0)
    # Rows are the North, East, Down unit vectors expressed in ECEF
    r = np.array([[-sl * co, -sl * so, cl],
                  [-so,       co,      0.0],
                  [-cl * co, -cl * so, -sl]])
    d = p_ecef - geodetic_to_ecef(lat0_deg, lon0_deg, h0)[0]
    return d @ r.T                                          # columns: N, E, D


def load_robot(path):
    df = pd.read_csv(path, usecols=["Time", "pose.pose.position.x",
                                    "pose.pose.position.y", "pose.pose.position.z"])
    df.columns = ["t", "lat", "lon", "h"]
    return df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=os.path.join(os.path.dirname(__file__), "..", "data"))
    ap.add_argument("--out", default="trajectories.html")
    ap.add_argument("--h-ref", type=float, default=None,
                    help="height of the water surface [m]; default = median of each robot's first 50 samples, averaged")
    args = ap.parse_args()

    robots = {}
    for path in sorted(glob.glob(os.path.join(args.data, "robot*_s1.csv"))):
        robots[os.path.basename(path).split("_")[0]] = load_robot(path)

    all_df = pd.concat(robots.values())
    lat0, lon0 = all_df.lat.mean(), all_df.lon.mean()
    h_ref = args.h_ref if args.h_ref is not None else float(
        np.mean([d.h.iloc[:50].median() for d in robots.values()]))
    t0 = all_df.t.min()

    fig = go.Figure()
    colors = ["#1f77b4", "#d62728", "#2ca02c", "#ff7f0e", "#9467bd"]
    for i, (name, d) in enumerate(robots.items()):
        ned = ecef_to_ned(geodetic_to_ecef(d.lat.values, d.lon.values, d.h.values), lat0, lon0, h_ref)
        east, north, depth = ned[:, 1], ned[:, 0], ned[:, 2]   # NED Down == depth below h_ref
        t_rel = d.t.values - t0
        c = colors[i % len(colors)]
        fig.add_trace(go.Scatter3d(
            x=east, y=north, z=depth, mode="lines", name=name, line=dict(color=c, width=3),
            customdata=t_rel,
            hovertemplate=f"{name}<br>E %{{x:.1f}} m<br>N %{{y:.1f}} m<br>depth %{{z:.1f}} m"
                          "<br>t %{customdata:.0f} s<extra></extra>"))
        fig.add_trace(go.Scatter3d(x=[east[0]], y=[north[0]], z=[depth[0]], mode="markers",
                                   marker=dict(size=5, color=c, symbol="circle"),
                                   name=f"{name} start", showlegend=False))
        fig.add_trace(go.Scatter3d(x=[east[-1]], y=[north[-1]], z=[depth[-1]], mode="markers",
                                   marker=dict(size=6, color=c, symbol="diamond"),
                                   name=f"{name} end", showlegend=False))

    fig.update_layout(
        title=f"Underwater robot trajectories (local NED origin: {lat0:.6f}°, {lon0:.6f}°; surface h = {h_ref:.2f} m)",
        scene=dict(xaxis_title="East [m]", yaxis_title="North [m]",
                   zaxis=dict(title="Depth [m]", autorange="reversed"),  # deeper = lower
                   aspectmode="data"),
        legend=dict(itemsizing="constant"), margin=dict(l=0, r=0, t=50, b=0))
    fig.write_html(args.out, include_plotlyjs="cdn")
    print(f"wrote {args.out}  (origin {lat0:.6f}, {lon0:.6f}; h_ref {h_ref:.2f} m)")


if __name__ == "__main__":
    main()
