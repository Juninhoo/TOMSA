// geodesy.hpp - header-only WGS84 geodesy and local-frame math (C++17).
// Geodetic (lat, lon, h) -> ECEF -> local NED. See docs/main.tex for the derivations.
#pragma once
#include <array>
#include <cmath>

namespace geo {

constexpr double kPi = 3.14159265358979323846;
inline double deg2rad(double d) { return d * kPi / 180.0; }
inline double rad2deg(double r) { return r * 180.0 / kPi; }

// ---------------------------------------------------------------- Vec3 / Mat3
struct Vec3 {
    double x{0}, y{0}, z{0};
    Vec3 operator+(const Vec3& o) const { return {x + o.x, y + o.y, z + o.z}; }
    Vec3 operator-(const Vec3& o) const { return {x - o.x, y - o.y, z - o.z}; }
    double dot(const Vec3& o) const { return x * o.x + y * o.y + z * o.z; }
    double norm() const { return std::sqrt(dot(*this)); }
};

class Mat3 {
public:
    Mat3(Vec3 r0, Vec3 r1, Vec3 r2) : r_{r0, r1, r2} {}
    Vec3 operator*(const Vec3& v) const { return {r_[0].dot(v), r_[1].dot(v), r_[2].dot(v)}; }
    Mat3 transposed() const {
        return {{r_[0].x, r_[1].x, r_[2].x}, {r_[0].y, r_[1].y, r_[2].y}, {r_[0].z, r_[1].z, r_[2].z}};
    }
private:
    std::array<Vec3, 3> r_;
};

// ---------------------------------------------------------------- Ellipsoid
class Ellipsoid {
public:
    constexpr Ellipsoid(double a, double invF) : a_(a), f_(1.0 / invF), e2_(f_ * (2.0 - f_)) {}
    static constexpr Ellipsoid WGS84() { return Ellipsoid(6378137.0, 298.257223563); }
    double a() const { return a_; }
    double f() const { return f_; }
    double e2() const { return e2_; }
    // Prime-vertical radius of curvature N(phi)
    double primeVertical(double latRad) const {
        const double s = std::sin(latRad);
        return a_ / std::sqrt(1.0 - e2_ * s * s);
    }
private:
    double a_, f_, e2_;
};

// ---------------------------------------------------------------- Points
struct Geodetic { double latDeg, lonDeg, h; };   // degrees, degrees, metres above ellipsoid
struct Ned { double north, east, down; };        // metres

// Geodetic -> ECEF (closed form)
inline Vec3 toEcef(const Geodetic& g, const Ellipsoid& el = Ellipsoid::WGS84()) {
    const double lat = deg2rad(g.latDeg), lon = deg2rad(g.lonDeg);
    const double n = el.primeVertical(lat);
    return {(n + g.h) * std::cos(lat) * std::cos(lon),
            (n + g.h) * std::cos(lat) * std::sin(lon),
            (n * (1.0 - el.e2()) + g.h) * std::sin(lat)};
}

// ---------------------------------------------------------------- Local tangent frame
class LocalFrameNed {
public:
    explicit LocalFrameNed(const Geodetic& origin, const Ellipsoid& el = Ellipsoid::WGS84())
        : el_(el), origin_(origin), originEcef_(toEcef(origin, el)), rEcefToNed_(buildRotation(origin)) {}

    Ned toNed(const Geodetic& g) const {
        const Vec3 v = rEcefToNed_ * (toEcef(g, el_) - originEcef_);
        return {v.x, v.y, v.z};
    }
    const Geodetic& origin() const { return origin_; }

private:
    // Rows: North, East, Down unit vectors expressed in ECEF
    static Mat3 buildRotation(const Geodetic& o) {
        const double lat = deg2rad(o.latDeg), lon = deg2rad(o.lonDeg);
        const double sl = std::sin(lat), cl = std::cos(lat), so = std::sin(lon), co = std::cos(lon);
        return {{-sl * co, -sl * so, cl}, {-so, co, 0.0}, {-cl * co, -cl * so, -sl}};
    }
    Ellipsoid el_;
    Geodetic origin_;
    Vec3 originEcef_;
    Mat3 rEcefToNed_;
};

}  // namespace geo
