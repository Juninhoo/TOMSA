// main.cpp - loads robot CSVs, converts to a common local NED frame, exports JSON for the HTML viewer.
// Build: g++ -std=c++17 -O2 -o traj_export main.cpp
// Run:   ./traj_export ../data ../web/trajectories.json
#include <algorithm>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include "geodesy.hpp"

namespace fs = std::filesystem;

struct Sample { double t; geo::Geodetic g; };

class Trajectory {
public:
    explicit Trajectory(std::string name) : name_(std::move(name)) {}
    void add(const Sample& s) { samples_.push_back(s); }
    const std::string& name() const { return name_; }
    const std::vector<Sample>& samples() const { return samples_; }
    double medianHeightOfFirst(size_t n) const {
        std::vector<double> h;
        for (size_t i = 0; i < std::min(n, samples_.size()); ++i) h.push_back(samples_[i].g.h);
        std::nth_element(h.begin(), h.begin() + h.size() / 2, h.end());
        return h[h.size() / 2];
    }
private:
    std::string name_;
    std::vector<Sample> samples_;
};

class CsvTrajectoryLoader {
public:
    static Trajectory load(const fs::path& path, const std::string& name) {
        std::ifstream in(path);
        if (!in) throw std::runtime_error("cannot open " + path.string());
        std::string line;
        std::getline(in, line);
        const auto header = splitCsv(line);
        const int iT = col(header, "Time"), iLat = col(header, "pose.pose.position.x"),
                  iLon = col(header, "pose.pose.position.y"), iH = col(header, "pose.pose.position.z");
        Trajectory tr(name);
        while (std::getline(in, line)) {
            if (line.empty()) continue;
            const auto f = splitCsv(line);
            if (f.size() <= static_cast<size_t>(std::max({iT, iLat, iLon, iH}))) continue;
            tr.add({std::stod(f[iT]), {std::stod(f[iLat]), std::stod(f[iLon]), std::stod(f[iH])}});
        }
        return tr;
    }
private:
    static int col(const std::vector<std::string>& h, const std::string& n) {
        auto it = std::find(h.begin(), h.end(), n);
        if (it == h.end()) throw std::runtime_error("missing column " + n);
        return static_cast<int>(it - h.begin());
    }
    // CSV split honouring double quotes (covariance fields contain commas)
    static std::vector<std::string> splitCsv(const std::string& s) {
        std::vector<std::string> out; std::string cur; bool q = false;
        for (char c : s) {
            if (c == '"') q = !q;
            else if (c == ',' && !q) { out.push_back(cur); cur.clear(); }
            else if (c != '\r') cur += c;
        }
        out.push_back(cur);
        return out;
    }
};

int main(int argc, char** argv) {
    const fs::path dataDir = argc > 1 ? argv[1] : "../data";
    const fs::path outPath = argc > 2 ? argv[2] : "../web/trajectories.json";
    try {
        std::map<std::string, Trajectory> robots;
        for (const auto& e : fs::directory_iterator(dataDir)) {
            const std::string fn = e.path().filename().string();
            if (fn.rfind("robot", 0) == 0 && e.path().extension() == ".csv")
                robots.emplace(fn.substr(0, fn.find('_')), CsvTrajectoryLoader::load(e.path(), fn.substr(0, fn.find('_'))));
        }
        if (robots.empty()) throw std::runtime_error("no robot*.csv found in " + dataDir.string());

        // Common origin: mean lat/lon over all samples; height = surface reference (mean of per-robot medians)
        double sLat = 0, sLon = 0, hRef = 0, t0 = 1e300; size_t n = 0;
        for (const auto& [k, tr] : robots) {
            for (const auto& s : tr.samples()) { sLat += s.g.latDeg; sLon += s.g.lonDeg; ++n; t0 = std::min(t0, s.t); }
            hRef += tr.medianHeightOfFirst(50);
        }
        hRef /= robots.size();
        const geo::LocalFrameNed frame({sLat / n, sLon / n, hRef});

        std::ofstream out(outPath);
        out.setf(std::ios::fixed); out.precision(3);
        out << "{\"origin\":{\"lat\":" << std::setprecision(10) << frame.origin().latDeg << ",\"lon\":" << frame.origin().lonDeg
            << ",\"h\":" << std::setprecision(6) << frame.origin().h << "},\"robots\":{";
        bool firstR = true;
        for (const auto& [name, tr] : robots) {
            out << (firstR ? "" : ",") << "\"" << name << "\":{\"t\":[";
            firstR = false;
            const auto& S = tr.samples();
            std::vector<geo::Ned> p; p.reserve(S.size());
            for (const auto& s : S) p.push_back(frame.toNed(s.g));
            for (size_t i = 0; i < S.size(); ++i) out << (i ? "," : "") << S[i].t - t0;
            out << "],\"east\":[";  for (size_t i = 0; i < p.size(); ++i) out << (i ? "," : "") << p[i].east;
            out << "],\"north\":["; for (size_t i = 0; i < p.size(); ++i) out << (i ? "," : "") << p[i].north;
            out << "],\"depth\":["; for (size_t i = 0; i < p.size(); ++i) out << (i ? "," : "") << p[i].down;
            out << "]}";
        }
        out << "}}\n";
        std::cout << "wrote " << outPath << " (" << robots.size() << " robots, " << n << " samples)\n";
    } catch (const std::exception& ex) {
        std::cerr << "error: " << ex.what() << "\n";
        return 1;
    }
    return 0;
}
