"""Generates numbers.tex (all figures quoted in main.tex) from the data and the C++ JSON output."""
import json, sys, numpy as np
sys.path.insert(0, '../python'); import viewer
J = json.load(open('../web/trajectories.json')); o = J['origin']
lat0, lon0, h0 = o['lat'], o['lon'], o['h']
phi = np.radians(lat0); s2 = np.sin(phi)**2
N = viewer.A/np.sqrt(1-viewer.E2*s2); M = viewer.A*(1-viewer.E2)/(1-viewer.E2*s2)**1.5
mN = np.radians(1)*(M+h0); mE = np.radians(1)*(N+h0)*np.cos(phi)
out = []
def cmd(n, v): out.append(f"\\newcommand{{\\{n}}}{{{v}}}")
cmd('latO', f"{lat0:.7f}"); cmd('lonO', f"{lon0:.7f}"); cmd('hO', f"{h0:.3f}")
cmd('Nrad', f"{N:,.1f}".replace(',', '\\,')); cmd('Mrad', f"{M:,.1f}".replace(',', '\\,'))
cmd('mperdegN', f"{mN:,.1f}".replace(',', '\\,')); cmd('mperdegE', f"{mE:,.1f}".replace(',', '\\,'))
rows, worst_lin, worst_py = [], 0, 0
for k, r in J['robots'].items():
    d = viewer.load_robot(f'../data/{k}_s1.csv')
    ned = viewer.ecef_to_ned(viewer.geodetic_to_ecef(d.lat.values, d.lon.values, d.h.values), lat0, lon0, h0)
    worst_py = max(worst_py, np.abs(ned[:,1]-r['east']).max(), np.abs(ned[:,0]-r['north']).max(), np.abs(ned[:,2]-r['depth']).max())
    lin = np.column_stack(((M+h0)*np.radians(d.lat.values-lat0), (N+h0)*np.cos(phi)*np.radians(d.lon.values-lon0), -(d.h.values-h0)))
    worst_lin = max(worst_lin, np.abs(lin[:,0]-ned[:,0]).max(), np.abs(lin[:,1]-ned[:,1]).max(), np.abs(lin[:,2]-ned[:,2]).max())
    dur = d.t.iloc[-1]-d.t.iloc[0]
    rows.append(f"{k.replace('robot','Robot ')} & {len(d):,} & {dur/60:.1f} & {np.median(np.diff(d.t)):.3f} & "
                f"[{ned[:,0].min():.1f}, {ned[:,0].max():.1f}] & [{ned[:,1].min():.1f}, {ned[:,1].max():.1f}] & {ned[:,2].max():.1f} \\\\".replace(',', '\\,',1) if False else
                f"{k.replace('robot','Robot ')} & {len(d)} & {dur/60:.1f} & {np.median(np.diff(d.t)):.3f} & "
                f"[{ned[:,0].min():.1f}, {ned[:,0].max():.1f}] & [{ned[:,1].min():.1f}, {ned[:,1].max():.1f}] & {ned[:,2].max():.1f} \\\\")
out.append("\\newcommand{\\datatable}{" + "\n".join(rows) + "}")
cmd('worstpy', f"{worst_py*1e6:.1f}"); cmd('worstlin', f"{worst_lin*1000:.2f}")
R = 6.371e6; cmd('curv', f"{300**2/(2*R)*1000:.1f}")
open('numbers.tex', 'w').write("\n".join(out)+"\n"); print("\n".join(out))
